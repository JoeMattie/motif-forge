# Handoff: Motif Forge UI polish pass — 18 tweaks

## Context

This is a **polish pass on the already-shipped Workbench UI** (live at motif-forge.pages.dev). The codebase is React + TypeScript + Vite + Mantine v7, with the workbench look implemented in `src/styles.css` (semantic CSS custom properties on `:root[data-theme='day'|'nite']`), `src/theme.ts` (Mantine component skins via `wb-*` classNames), and custom hardware components in `src/components/hw/` (`Knob`, `HardToggle`, `PlayRound`, `RateSquares`, `CircleOfFifths`).

These tweaks were identified from screenshots of the live app (included in `screenshots/`). Each item says what's wrong, why, and the intended fix. **Do not restyle anything not listed here** — the overall design is right; this is targeted cleanup. Keep both themes (Day + Nite) working for every change.

The original design reference (`Motif Forge Directions.dc.html`) is included for token values and the intended look of specific elements (transform key grid, cable colors, LCD treatment). Screens 5a/4b/3a/6a/6b/7a are the committed direction.

---

## A. Generate panel — kill the whitespace

### A1. MODE list sets the panel height — replace with a knob (HIGH)
The 7-item vertical SegmentedControl for MODE (~250px tall) is the tallest element in `.gen-module`; every other column ends ~90px higher, leaving a dead band across the bottom ~40% of the panel.

- Replace the vertical MODE seg with the existing `Knob` component: 7 detents, value = the 3-letter mode code (`ION DOR PHR LYD MIX AEO LOC`), same size as other knobs (45px), `variant="light"`, keeping the dice toggle in the caption row.
- Expected result: `.gen-module` height drops from ~330px to ~230px — one extra card row above the fold.
- **Apply the same replacement in the Noodle panel** (`NoodlePanel.tsx` has an identical 7-item vertical MODE seg next to the CircleOfFifths).
- Keep keyboard access: knob already supports arrow keys via AngleSlider.

### A2. Batch progress bar: loud green → quiet LCD chip when idle (HIGH)
`GenProgress` renders a full-width saturated green fill reading "5 ADDED" permanently after a batch completes — it's the most saturated element on screen at rest and outshouts the actual primary buttons.

- **While running:** keep the current full-width strip (accent fill + pendpulse is right).
- **On completion:** collapse to a compact LCD-style status chip — dark `var(--lcd-bg)` background, mono 10px `var(--note-harmony)`-green text, like the existing `.noodle-status` class — reading e.g. `✓ 5 ADDED`. Auto-fade it (opacity → 0 over ~400ms) after ~6 seconds; it can reappear in the collapsed strip's summary if useful.
- **On failure:** same treatment with `var(--danger)` text, but do NOT auto-fade.

### A3. MOOD/ENERGY knobs: align captions, fill the column (MED)
The two INSTANT-engine knobs float at the top of their column with dead space below, and their captions (`MOOD NEUT` above the knob) don't match the other columns' caption rows.

- Stack the two knobs vertically in one `gen-ctl` so the column fills the (now shorter, post-A1) panel height.
- Use the standard `knob-label` caption row (label + bold value), same y-position as neighboring columns' captions.

### A4. Disabled brief fields look broken (MED)
When the engine ignores the brief (INSTANT/GENETIC/NEURAL), the concept + brief inputs render disabled but still show their full placeholder prose — grey ghost fields that look like a bug (see `02-genpanel-genetic-groove.png`).

- When `!briefApplies`: hide the two inputs entirely and render one micro-label line in their place: `brief applies to the CLAUDE engine` (`.micro`, `var(--faint)`), plus keep the concept value if set as a plain chip.
- The column keeps its width (`.gen-mid`) so the layout doesn't jump when switching engines.

### A5. LEAD chip reads as disabled (MED)
Grey fill + orange check on the always-on LEAD chip reads "disabled" next to RHYTHM's dark latch. If LEAD is mandatory for the current voicing:
- Render it latched-dark like a checked chip, with a small lock glyph (Phosphor `LockSimpleIcon` 9px) instead of the check, and a tooltip "LEAD is always included for LINE voicing".
- Truly disabled chips (e.g. LINE greyed under NEURAL) keep the current dim treatment.

---

## B. Triage grid

### B1. Allow 4 columns at wide widths (HIGH)
At ~1440px the grid renders 3 columns + a ~270px empty right rail. Adjust `useGridColumns` / the grid CSS so ≥1400px container width yields 4 columns (~330px cards — the design mock ran 4-up at 1480). Keep the current behavior below that.

### B2. Rating squares contrast in Nite (MED)
The 9px `.rate-sq` outlines are near-invisible on Nite card backgrounds.
- Bump squares to 10–11px.
- In Nite, give unfilled squares a lighter border (e.g. one step up from `--surface-border`) and/or a subtle `background: rgba(255,255,255,.04)`. Verify on `10-triage-grid-nite.png`'s card footer.

### B3. Consistent card heights (LOW)
Single-part motifs skip the part-legend row, so cards in the same row can have different heights (Ember vs Walk rows). Always render the `.part-legend` row (empty is fine — it reserves height), and put the CHR chip there in all cases.

---

## C. Noodle panel

### C1. Distribute the controls row (HIGH)
The control columns end at ~950px leaving ~450px dead space to the right, while the roll below runs full-width. Either `justify-content: space-between` on `.noodle-controls`, or `margin-left: auto` on the TIMING group — the goal: the controls row and the roll share left/right edges.

### C2. Auto-fit the roll's pitch range + cap height (HIGH)
The roll is ~260px tall but the take occupies 2 octaves squeezed in the middle; vast empty rows above/below, and the transport row (Quantize / To key / Undo / Clear / Add to pool) falls below the fold.
- Auto-fit the visible pitch range to the take's min/max note ± 2 rows (with a sane minimum span, e.g. 1.5 octaves; empty take defaults to C3–C6 as now).
- Cap the roll's rendered height at ~200px; it already scrolls for bigger ranges.
- Recompute fit when notes are replaced (new recording/transcription), NOT on every edit (no viewport jumping mid-pencil).

### C3. Count-in + latency inputs (MED)
Two bare spinners (`1`, `60`) read as mystery numbers.
- Count-in: replace the NumberInput with a `1 | 2` SegmentedControl captioned `count-in`.
- Latency: move into a small advanced popover (gear/`ADV` key at the end of the mic row — same pattern as the bay's `AdvancedPop`), rendered as a NumberInput with a `ms` suffix and its existing tooltip.

### C4. REC button states (MED)
REC is red-outlined at idle — it looks already-armed.
- Idle: neutral hardware key (default `wb-btn`), label `REC`.
- Armed: red fill (`var(--danger)`, white text) with the label `ARMED…` and a slow blink.
- Recording: solid red, label `STOP REC`, steady.
- Same principle for the mic `RECORD` button (neutral idle → red while capturing).

### C5. Bar ruler on the roll (MED)
Add a micro ruler row along the top of the roll SVG: bar numbers (`1 2 3 4`) at each barline, mono 7px `var(--lcd-dim)` — same style as the octave labels. Sticky with vertical scroll like the velocity lane is with horizontal.

### C6. Live-state feedback on the roll (LOW)
While armed/recording, add a red ring on the roll shell: `.noodle-roll-shell[data-live] { box-shadow: 0 0 0 2px var(--danger), 0 0 12px rgba(danger,.4) }`. Also render the `noodle-status` chip in the **collapsed** strip too — currently collapsing the panel while armed hides all live indication.

### C7. Hotkey legend (LOW)
Add a printed micro-legend line under the roll, same style as the triage legend: `pencil draws · select drags marquee · alt-click deletes · z/x octave`.

---

## D. Mutation bay (React Flow graph)

### D1. Color edges by mutation type (HIGH)
All edges are faint grey. Color-code them like the design's patch cables — this is the single highest-value identity fix:
- deterministic transform (ADV ops): `#3ba07e` green
- Claude/LLM takes: `#f14d0e` orange
- other/evolve: `#e8b23c` yellow
- 2.5–3px stroke, rounded caps, slight opacity (.8); selected/in-mix path at full opacity.
- Add a small cable legend chip group in a corner of the canvas (module-bg card, like the mock's CABLE LEGEND in 3a).

### D2. Name + type badge on child nodes (HIGH)
Child nodes are anonymous (just a roll + USE/MUTATE/CLAUDE/ADV keys). Add the tray-card header row: take name (11px/600) left, type badge right (`VAR · EVO`, `CLAUDE`, `R-INV`…) colored to match its edge per D1. Keeps the lineage readable at a glance.

### D3. Skin the ADV popover (MED)
The ADV dropdown is default white Mantine chrome amid the hardware (see `07-mutation-bay-adv-dropdown-day.png`).
- Popover surface: `var(--module-bg)`, `var(--module-border)`, 12px radius, module shadow.
- Ops as the mock's 3-column hardware key grid (INVERT / RETRO / R-INV / 8VA / 8VB / MODE SWAP), `wb-btn` styling.
- TRANSPOSE: a compact stepper (`−  +2  +`) or 25px knob instead of the native spinner; MODE SWAP's select keeps Mantine Select (already skinned via theme).

### D4. Skin the minimap (MED)
Default grey React Flow minimap → LCD treatment: `maskColor` derived from `--lcd-bg` at ~80% alpha, node color `--note-lead` cream, background `--lcd-bg`, 6px radius, `inset 0 2px 6px rgba(0,0,0,.5)`. It becomes a little hardware scope.

### D5. fitView on open (LOW)
The tree floats small in a huge canvas on open. Call `fitView({ padding: 0.25, maxZoom: 1 })` on mount and after a mutation batch lands.

---

## E. Global

### E1. Color roles: orange = create, green = keep, red = destroy (MED — discuss before doing)
Green currently serves as primary in several places (GENERATE, ADD TO POOL, the CLAUDE node key), competing with orange. Proposed:
- GENERATE / GENERATE +5 → orange (accent) — creation is the app's primary verb.
- ADD TO POOL / USE / KEEP / promote actions → green — commit/keep.
- Discard/clear/stop-rec → red as now.
- CLAUDE keys: keep green if you want "Claude = green" as a brand cue, but then GENERATE must be orange so green isn't doing two jobs.
This is a product call — implement only after confirming with the owner.

---

## Verification checklist

For each change, check **both themes** and the container-query wrapped layout (<1272px):
- [ ] Generate panel ≤ ~240px tall with INSTANT engine; no dead band under engine/brief columns
- [ ] Batch chip idles quiet; running state unchanged
- [ ] Engine switching doesn't jump the panel width/height (A4 keeps `.gen-mid` width)
- [ ] 4 card columns at ≥1400px; 3 below
- [ ] Rating squares legible on Nite
- [ ] Noodle controls + roll share edges; transport row visible at 900px viewport height
- [ ] Roll auto-fit doesn't re-fit during pencil edits
- [ ] Bay edges colored + legend present; ADV popover matches module skin
- [ ] No regressions to keyboard triage (1–5, F, M, arrows), knob arrow-key input, or the recording flows

## Files in this bundle
- `README.md` — this document
- `Motif Forge Directions.dc.html` — original design reference (tokens, transform grid, cable colors)
- `screenshots/` — the live-app captures these tweaks were identified from (01–07 Day, 10 Nite)
