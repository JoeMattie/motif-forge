# Handoff: Motif Forge "Workbench" UI

## Overview

A full visual + UX redesign of Motif Forge (the motif generation / triage / mutation / leitmotif tool). The direction is **"Workbench"**: a Teenage-Engineering-style light hardware panel — matte warm-gray plastic modules, chunky 3D-shadowed buttons, rotary knobs, toggle switches — with all piano rolls rendered on inset dark **LCD screens**. Two structural UX changes ride along with the skin:

1. **Families** — mutations are encapsulated inside each motif card. The triage grid only ever shows one *promoted take* per family; variants live in a fold-out tray. Pool counts never inflate.
2. **Per-part lock/vary** — polyphonic motifs expose each part (lead / harmony / bass / drums) as a channel strip with LOCK and VARY switches; LLM mutation only touches armed parts, and the mutation bay visualizes lineage as physical patch cables color-coded by which part varied.

**Ship BOTH themes** — light ("Day", the default) and dark ("Nite") — behind a user-facing theme toggle (plus follow-system option). They share every accent, LCD, and layout token; only the panel tokens swap (see the two color tables below). Screen 7a shows the triage grid fully rendered in Nite as the reference for how the mapping is applied.

## About the Design Files

The file in this bundle (`Motif Forge Directions.dc.html`) is a **design reference created in HTML** — a static hi-fi prototype showing intended look and behavior, not production code to copy. The task is to **recreate these designs in the existing motif-forge codebase** (React + TypeScript + Vite + **Mantine v7** — keep Mantine, restyle it via the theme + custom components). Do not port the HTML wholesale; lift the exact values documented below and rebuild with the codebase's existing component structure (`MotifCard`, `TriageGrid`, `GenerationPanel`, `MutationPanel`, `PianoRoll`, `TransportBar`, `LibraryView`, `ConceptView`).

The HTML file is a design canvas containing several numbered iterations (newest at top). Early explorations (turns 1–2) have been removed from this copy; everything present is part of the committed direction:

- **5a** — Triage grid with families (THE main screen; supersedes 4a)
- **4b** — Focus triage mode (mode switch within Triage)
- **3a** — Mutation bay, polyphonic with per-part lock/vary (supersedes 2a)
- **6a** — Library
- **6b** — Concepts / leitmotif desk
- **7a** — Dark theme ("Nite") of the triage grid — the token mapping for a full dark mode. Apply the same mapping to every other screen; there is no separate dark mock per screen.

(4a shows the grid before families and the expanded generation knob module — use it for the generation-module spec; 5a supersedes its card grid.)

## Fidelity

**High-fidelity.** Colors, typography, spacing, radii, and shadows are final intent — recreate pixel-perfectly using Mantine's theming where possible and custom components where Mantine has no equivalent (knobs, LCD piano roll, patch cables, part channel strips). Note the mockups are drawn at 1480px width; treat layouts as fluid (CSS grid / flex) with these proportions.

## Design Tokens

### Color — panel (light hardware)
| Token | Value | Use |
|---|---|---|
| `panel-bg` | `#dcd9d2` | app background (warm gray plastic) |
| `module-bg` | `#e8e6df` | module/card surface |
| `module-border` | `#c4c1b8` | all hairline borders, button 3D shadows |
| `tray-bg` | `#d0cdc5` | inset fold-out trays / concept groups |
| `well-bg` | `#c9c6bd` | done/disabled cards, stack lips |
| `surface` | `#ffffff` | inputs, secondary buttons, chips |
| `ink` | `#26251f` | primary text, dark buttons/knobs |
| `ink-dim` | `#4a483f` | secondary button text |
| `label` | `#6d6a5f` | control labels |
| `label-dim` | `#8b887d` | micro-labels, meta |
| `faint` | `#a5a296` | hints, dashed borders, disabled |

### Color — accents
| Token | Value | Use |
|---|---|---|
| `accent` | `#f14d0e` | primary actions, playing state, playhead, VAR·HARMONY cable |
| `accent-pressed` | `#b93400` | 3D shadow under orange buttons |
| `green` | `#3ba07e` | deterministic-transform badges/cables, lit rating key |
| `yellow` | `#e8b23c` | VAR·DRUMS cable/badges (text on light: `#c98f1a`) |
| `danger` | `#c0392b` | discard |

### Color — LCD (dark screens)
| Token | Value | Use |
|---|---|---|
| `lcd-bg` | `#1c1e1a` | LCD surface (`#141613` for the large focus LCD inner area) |
| `lcd-grid` | `#2c2f29` | bar lines (beat lines `#20231e`) |
| `lcd-text` | `#f0efe6` | LCD headline text |
| `lcd-dim` | `#6f7a6a` | LCD secondary text |
| `note-lead` | `#e6e4d5` | part 0 notes (warm white) |
| `note-harmony` | `#7fc98f` | part 1 |
| `note-bass` | `#7aa2d4` | part 2 |
| `note-drums` | `#d48a9b` | part 3 (drawn as short ticks on the bottom lane) |
| `note-chromatic` | `#f1a33c` | out-of-scale notes |
| `note-muted` | `#8a9784` | notes on discarded/done cards |

Locked/context parts in variant rolls render at `opacity: .45–.55`; the varied part at full opacity. Velocity maps to note opacity (~0.55–1).

### Color — dark theme ("Nite", screen 7a)
Same accents and LCD values; panel tokens invert. **Active tabs/filters latch as inset dark wells** (`background:#111009`, lit text `#f0efe6`, `inset 0 2px 4px rgba(0,0,0,.6)`, small glowing orange LED dot before the label — 5px dot, `box-shadow: 0 0 5px rgba(241,77,14,.9)`). Cream (`#e8e6df` fill, `#1d1c19` text) is reserved for pressed-style buttons and small state chips (rating squares, toggles-on, PROMOTED/FAMILY chips). Fold-out trays get extra top padding (22px) so content clears the anchor-card seam:

| Light token | Dark value |
|---|---|
| `panel-bg` | `#161512` |
| `module-bg` | `#26251f` |
| `module-border` | `#3a382f` |
| `surface` (inputs/secondary buttons) | `#32302a` (border `#454238`) |
| `tray-bg` | `#131210` |
| `well-bg` / stack lip | `#211f1b` / `#3a382f` |
| `ink` (text) | `#e8e6df` (secondary `#c9c6bd`) |
| `label` / `label-dim` / `faint` | `#a19e93` / `#8b887d` / `#6d6a5f` |
| 3D button shadow | `0 2px 0 #0c0b09` |
| module top highlight | `inset 0 1px 0 rgba(255,255,255,.06)` |
| selected ring / tray border | `#a5a296` |
| `danger` | `#e06550` |
| yellow badge text | `#e8b23c` |

Toggles invert (on-track cream, thumb dark); rating squares fill cream; drop shadows deepen to `rgba(0,0,0,.4)`.

### Typography
- **Panel font:** `'Space Grotesk', system-ui, sans-serif` (Google Fonts, 400/600/700)
- **LCD font:** `'IBM Plex Mono', monospace` — everything on dark LCDs
- Micro-labels: 8–9.5px, `letter-spacing: .08–.18em`, UPPERCASE, weight 600–700
- Card titles: 11–11.5px / 600; LCD headline 16px; module headings 13–14px / 700
- Brand: `MOTIF–FORGE` 14px / 700 / `.06em` + sub-label 9px `.14em` (e.g. `TRIAGE DECK · MF–01`)
- In production, scale this type ramp up ~1px across the board if it reads small at real DPI.

### Radii
Modules/cards `12px` · inner cards/buttons `7–8px` · LCDs `6px` · chips/badges `3–4px` · knobs/round buttons `50%`.

### Shadows (the material system — apply consistently)
- Module: `inset 0 1px 0 #fff, 0 2px 6px rgba(0,0,0,.08)`
- 3D button (white): `0 2px 0 #c4c1b8` — dark: `0 2px 0 #000` — orange: `0 3px 0 #b93400` (primary buttons get 3px). Pressed/latched state: remove drop, add `inset 0 2px 3px rgba(0,0,0,.25–.3)`
- LCD: `inset 0 2px 6px rgba(0,0,0,.5)` (large focus LCD: `inset 0 2px 12px rgba(0,0,0,.6)`)
- Playing highlight: `outline: 2px solid #f14d0e; outline-offset: 2px` + `0 3px 10px rgba(241,77,14,.18)`
- Selected (keyboard cursor): `border-color:#26251f` + `0 0 0 1px #26251f`
- Tray: `inset 0 2px 6px rgba(0,0,0,.08)`

### Hardware controls (custom components)
- **Knob:** 44–46px circle. Dark: `background:#26251f; box-shadow: 0 2px 4px rgba(0,0,0,.25), inset 0 1px 0 rgba(255,255,255,.15)`. Light: white + border. Indicator: 2.5×11px rounded tick from top-center, rotated around the knob center. Label below: micro-label + bold value.
- **Toggle switch:** 22×12px pill, 9px thumb. On: `#26251f` track, thumb right, light thumb. Off: `#c4c1b8` track, white thumb left. Accent toggles use `#f14d0e` / `#e8b23c` tracks.
- **Rating keys:** five 9px squares on cards (filled `#26251f` = rating); in focus mode five 34px keypad keys, current rating latched green `#3ba07e`.
- **Round play button:** 26px on cards (white bordered, `▶` ink) / orange when playing (`■` white). 72px orange master play in focus mode; 52px white prev/next.

## Screens / Views

### 1. Triage — Grid mode (5a) — THE primary screen
- **Header** (all screens share it): brand left; view pills right (`TRIAGE / LIBRARY / CONCEPTS` — active = dark fill; MUTATE appears as a 4th pill only while the mutation bay is open); vertical divider; GRID/FOCUS segmented switch.
- **Generation strip (collapsed):** one-line module — `GENERATE ▾` + current brief summary + `+ 5` (orange), `+ 20` (dark), `⚂` (white) buttons. Expands to the full knob module (see 4a in the mock): KEY/MODE/TEMPO/BARS knobs, brief textarea, LEAD/RHYTHM/CHROMATIC toggles, concept field.
- **Filter row:** hardware keys `ALL / UNRATED / RATED / DISCARDED` with counts (active = dark latched); a dashed chip noting `COUNTS = FAMILIES · VARIANTS STAY INSIDE`; right-aligned printed keyboard legend: `← → ↑ ↓ NAV · SPACE PLAY · 1–5 RATE · X DISCARD · F FOLD OUT · M MUTATE`.
- **Card grid:** 4 columns, 12px gap. Card anatomy (top→bottom, 11px padding, 7px gaps): title row (name 11px/600 + `4B · 96` meta) → LCD piano roll (88px, bar-line background) → footer row (play button, five rating squares, spacer, `FAMILY ▸ N` chip).
- **Family affordances:** cards whose family has >1 variant get a **stack lip** — a 4px well-colored strip peeking over the top edge (`left/right: 6px; top: -4px; radius 6px 6px 0 0`). The `FAMILY` chip is dark+`▾` when expanded, bordered+`▸` otherwise.
- **Fold-out tray:** expanding a family (F key or chip) opens a full-width tray directly under that card's row (`grid-column: 1 / -1`, tray-bg, joined to the card: card gets `border-radius 12px 12px 0 0; border-bottom: none`, tray `border-radius 0 12px 12px 12px`, both with ink border). Tray contents: header (`FAMILY — <NAME>` + variant count/best + `OPEN MUTATION BAY →` + `▴ FOLD`) and a horizontal strip: **ORIGIN** mini-card → `→` → variant mini-cards (name, transform badge, 52px LCD, play, rating, PROMOTE) → dashed `+ NEW VARIATION` slot. The **promoted** variant gets the orange outline and a dark `PROMOTED ●` chip; a discarded variant renders at .55 opacity with strikethrough + RESTORE.
- **Card states:** playing (orange outline + moving playhead + orange stop button), selected (ink ring), discarded (well-bg, .6 opacity, strikethrough, `DISCARDED · U TO UNDO` chip + RESTORE), pending batch (dashed border, pulsing, three orange dots + `GENERATING 10 · <label>`).
- **Bottom transport strip:** now-playing (orange stop + name + `BAR 2.3`), divider, `SOUND` value, FORCE/FIXED/CLICK/DRONE toggles (FIXED shows its BPM), spacer, `TRIAGE PROGRESS` + 160px progress bar (orange fill) + percent.

### 2. Triage — Focus mode (4b)
- Generation collapses to the one-line strip.
- **Large LCD** (fills width beside controls): headline `NAME · 17/47 · KEY MODE · BARS · N PARTS`, blinking `▶` + big BPM digits; 250px multi-part roll with sweep playhead; footer: part legend (color chip + `LEAD · EPIANO` etc.) + the motif's rationale in quotes.
- **Physical control cluster** (270px right panel): prev / 72px orange play / next; five rate keys (auto-advance on rate); `✕ DISCARD` / `⟳ MUTATE`; `.MID` / `.WAV`; session telemetry (`SESSION PACE 9/MIN`, `REMAINING ~3 MIN`, progress bar).
- **Queue strip:** thumbnails of done (dimmed, `✓ ★★★★` / `✓ DISCARDED`), current (dark card, orange outline, `● NOW`), upcoming (white cards), pending (dashed). Rating or discarding auto-advances.

### 3. Mutation Bay (3a) — opens scoped to ONE family
- **SOURCE module** (left, 440px): family name + meta; 148px 4-part LCD with playhead; `PART CHANNELS` label + one **channel strip per part**: color chip, NAME (bold), instrument, LOCK toggle, VARY toggle. Armed strips get a border in their cable color (`#f14d0e` harmony, `#e8b23c` drums) + bold colored `VARY ●`; locked strips show dark `LOCK 🔒`. Lineage chips at bottom (`GEN BATCH #4 → MODE SWAP PHRY → THIS`).
- **TRANSFORM + LLM module** (below source): header `TRANSFORM — UNLOCKED PARTS ONLY` + armed count; deterministic buttons (INVERT / RETRO / AUG ×2 / DIM ×.5 — apply instantly, client-side, to unlocked parts); LLM section: armed-part names in their colors, brief input, LOCK RHYTHM toggle, orange `RUN ▸`, `⚂`; note: *locked parts are copied into every child verbatim*.
- **Patch cables** (SVG overlay): 6px rounded-cap beziers from **the armed part's jack on the source module's right edge** to each child card's left-edge jack, color = which part varied; each cable has a soft shadow twin (`#1f1e1a` at .14, +4px y). Jacks: 9px dark circle + 4px colored core. A dashed low-opacity cable = pending patch, dangling into an unplugged jack. **Implement with a component that measures real DOM positions (getBoundingClientRect) — do not hardcode coordinates.**
- **Children column:** variant cards with left accent border in cable color, type badge (`VAR · HARMONY`, `VAR · DRUMS`, `TRANSFORM · R-INV`), part-badge row (`LEAD 🔒` bordered / `HARMONY ✱` filled in cable color), LCD with locked parts dimmed, footer (play, stars, KEEP, SOLO VAR, .MID, .WAV). Active child: orange outline + playhead.
- **Right column:** `A/B AUDITION` module (A·SOURCE / B·CHILD latch buttons + `LOOP · SWAP ON BAR` toggle — flip while looping, only the varied part changes); pending status; CABLE LEGEND; part-activity VU meters (bars in part colors).

### 4. Library (6a)
- **Toolbar module:** `MIN RATING` ★1–★5 hardware keys (latched = dark); `CONCEPT` filter select; count readout (`12 FAMILIES KEPT · 31 VARIANTS INSIDE`); new-concept input + dark `+ CONCEPT`; orange `EXPORT ALL .MID`.
- **Grid:** same family cards as triage plus a **concept footer row** under a divider: concept chip (dark = tagged; colored per concept is acceptable; dashed `NO CONCEPT ▾` = untagged — the chip is a select) + `.MID` `.WAV`.

### 5. Concepts / Leitmotif desk (6b)
- **Concept tabs:** hardware keys with counts (`EVENT HORIZON · 6` active/dark), dashed `+ NEW`; hint text right.
- **Summary module** for the active concept: name, `2 ROOT MOTIFS · 6 FAMILIES · USED ON TRACK 01 · 03 · 04 · BEST ★★★★★`, orange `PLAY ALL IN SEQUENCE`, `EXPORT CONCEPT .MID`.
- **One tray per root motif:** left — root card (380px) with `ROOT` tag, LCD, rating, TRACK chip; right — `DERIVED FOR OTHER TRACKS — N` + orange `TRANSFORM FOR NEW TRACK →` (opens the mutation bay pre-scoped), then derived-variant mini-cards (transform badge, 48px LCD, play, TRACK chip or dashed `UNASSIGNED`, rating) and a dashed `+ DERIVE A VARIANT FOR THE NEXT TRACK` slot.

## Interactions & Behavior

- **Keyboard (grid):** arrows move selection; space play/stop; 1–5 rate; X discard; U undo discard; **F fold/unfold family tray**; M open mutation bay for selected family. (Focus mode: rating/discard auto-advance; ←/→ prev/next.)
- **Playback:** playing card is unmissable — orange outline, glow, orange stop button, 2px orange playhead sweeping the LCD (linear, loops, `box-shadow: 0 0 10px rgba(241,77,14,.8)`). Blinking `▶` on the focus LCD: 1s steps.
- **Pending batches:** dashed pulsing placeholder (opacity .4→1, 1.4s ease-in-out infinite) in grid/queue; results replace it in place.
- **Family promote:** PROMOTE on a tray variant makes it the family's face everywhere (grid, exports, transport). Exactly one promoted take per family (origin by default).
- **Lock/vary:** toggles are mutually exclusive per part (arming VARY clears LOCK and vice versa; default LOCK). RUN disabled when no part is armed.
- **A/B audition:** latches A or B while looping; swap happens on the next bar boundary.
- **Buttons:** hover raises brightness slightly; active translates down 2px and removes the 3D shadow (the "press"). Latched keys keep the inset shadow. All hit targets ≥ 26px; primary ≥ 40px.
- **Transitions:** ~80–120ms on borders/shadows; tray fold ~180ms height ease-out. No springy motion — hardware feel is immediate.

## State Management

Extends the existing reducer/IndexedDB store:

- `theme: 'day' | 'nite' | 'system'` — persisted; drives a Mantine color-scheme + CSS-variable swap (define both palettes as CSS custom properties on `:root[data-theme]`; components reference only the semantic tokens).
- `Motif` gains: `familyId` (or derive family = root + descendants via existing lineage), `promoted: boolean` (one per family), `trackId?: string` (Concepts view assignment).
- Part-level UI state (not persisted per se): `lockedParts: Set<number>` / `armedParts: Set<number>` per mutation-bay session; `lockRhythm` flag as today.
- View state: `triageMode: 'grid' | 'focus'`, `expandedFamilyId: string | null`, `abAudition: 'A' | 'B'`, session pace telemetry (ratings timestamped this session).
- Filters count **families** (group motifs by root), not motifs. Variants inherit the family's concept tag.
- LLM mutation payload includes locked parts verbatim and instructs the model to only rewrite armed parts (validate: locked-part notes must round-trip unchanged, else drop the child).

## Assets

No binary assets. Fonts from Google Fonts: **Space Grotesk** (400/600/700) and **IBM Plex Mono** (400/500/600). Icons are text glyphs (▶ ■ ← → ✕ ⟳ ⚂ ▾ ▸ ★ 🔒 ✱) — replace with a consistent icon set if preferred, keeping the same sizes. Patch cables, knobs, toggles, and LCDs are pure CSS/SVG per the specs above.

## Mantine Integration Notes

- Rewrite `src/theme.ts`: support **both color schemes** (`light` = Day, `dark` = Nite) with the semantic tokens above as CSS variables, `fontFamily: 'Space Grotesk'`, `fontFamilyMonospace: 'IBM Plex Mono'`, primary color from `#f14d0e` tuple, `defaultRadius: 'md'` (≈7–8px), and per-component `styles` for Button (3D shadow + pressed state), SegmentedControl (GRID/FOCUS, view pills — dark scheme uses the inset-well + LED-dot latch), Chip, TextInput/Textarea (surface + inset shadow), Rating (custom square swatches), Slider, Tooltip.
- Custom components to build: `Knob`, `HardToggle`, `LcdRoll` (replaces PianoRoll's styling — keep its SVG note logic, restyle colors/background), `FamilyTray`, `PartChannelStrip`, `PatchCables` (measured SVG overlay), `StackLip`.
- Keep the existing `--var` CSS-custom-property approach in `styles.css` but swap the palette to the tokens above.

## Files

- `Motif Forge Directions.dc.html` — the design canvas. Open in a browser; iterations are numbered, newest at top. Committed screens: **5a, 4b, 3a, 6a, 6b, 7a (dark)**; 4a is reference for the expanded generation module.
